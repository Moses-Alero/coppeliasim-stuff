# Java ZMQ Remote API

This project contains ZMQ Remote API client for Java.

## Requirements

 - **Java 1.8+**
 - **[JeroMQ](https://github.com/zeromq/jeromq)**
 - **[cbor-java](https://github.com/c-rack/cbor-java)**

## Building:

```
mvn package
```
