# MATLAB ZMQ Remote API

This library contains ZMQ Remote API client for MATLAB.

## Requirements

 - **MATLAB R2019b**
 - **JeroMQ** (bundled)

## Examples

See the scripts in this directory for a few usage examples.
